# DeepCard
<h3>The Website</h3>
This website helps you make personalized cards, for birthdays and other occations. You make them by either starting the card, and a funny AI will complete you, or write the card without any help from the AI. After making the card, you can get a custom link to give out to your friends! Everything on this website is absolutely free to use. Access the website <a href="https://deepcardai.herokuapp.com/" target="_blank">here</a> <p>***The website may take a few seconds to load because of how herokus servers work
<h3>Our Team</h3>
This project was developed by Nerya, Ido and Dolev for the Tech With Tim code jam. We enjoyed working together and watching the project grow from a simple idea to a fully working (and quite hilarious) website.
<h3>Our Tools</h3>
We combined forces and used Python for the Natural-Language-Processing Deep-Learning Neural Network, and used JavaScript, HTML and CSS to design the beautiful website that interacts with the Neural Network
The full path of the website is http://deepcardai.herokuapp.com/ Enjoy!
